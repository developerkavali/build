import { default as Data } from '../db/consumer-trends'

export default class DataService {
    getAll() {
        return Data;
    }

    getRetail() {
        return Data.Retail;
    }

    getTravelEnt() {
        return Data.TravelEnt;
    }

    getServices() {
        return Data.Services;
    }
}