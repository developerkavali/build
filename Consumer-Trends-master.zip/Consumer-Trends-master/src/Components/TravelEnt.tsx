import React, { useState, useEffect } from 'react';
import DataService from '../api/DataService';
import Chart from "react-google-charts";

function TravelEnt() {
  const [TravelEnt, setTravelEnt] = useState([]);
  let ds = new DataService();

  useEffect(() => {    
    populateTravelEntChartData()
  }, []);

  function populateTravelEntChartData() {
    const columns = [
      { type: "string", label: "Week Of" },
      { type: "number", label: "Yr-over-Yr % Vol Growth" },
      { type: "number", label: "Yr-over-Yr % Txn Growth" },
      { type: "number", label: "Yr-over-Yr % Vol Growth AVG" },
      { type: "number", label: "Yr-over-Yr % Txn Growth AVG" }
    ];

    let items = ds.getTravelEnt();
    let dataRows = [];
    
    for (let i = 0; i < items.length; i++) {
      let para_arr = [];
      para_arr.push(items[i]['WeekOf'] ? items[i]['WeekOf'] : "0")
      para_arr.push(items[i]['VolGrowth'] ? items[i]['VolGrowth'] : 0)
      para_arr.push(items[i]['TxnGrowth'] ? items[i]['TxnGrowth'] : 0)
      para_arr.push(items[i]['VolGrowthAVG'] ? items[i]['VolGrowthAVG'] : 0)
      para_arr.push(items[i]['TxnGrowthAVG'] ? items[i]['TxnGrowthAVG'] : 0)
      dataRows.push(para_arr);
    }

    let resultData : any = [columns, ...dataRows];
    setTravelEnt(resultData);
  }

  return (
    <div>
        <h3>National Consumer Spending Trends - Travel & Entertainment</h3>
        <br />
        <div>
          <Chart
            chartType="LineChart"
            data={TravelEnt}
            loader={<div>Loading National Consumer Spending Trends Travel & Entertainment Chart....</div>}
            graphID="LineChart-TravelEnt"
            width="100%"
            height="400px"
            options={{
              title: '',
              legend: 'top',
              hAxis: {
                title: 'Week Of...',
              },
              vAxis: {
                title: '%',
              },
              series: {
                2: {
                  lineDashStyle: [4, 4]
                },
                3: {
                  lineDashStyle: [4, 4]
                }
              },
            }}
          />
        </div>
    </div>
  );
}

export default TravelEnt;