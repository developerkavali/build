import React, { useState } from 'react';
import Retail from './Retail';
import TravelEnt from './TravelEnt';
import Services from './Services';
import '../assets/main.css';

function App() {
  const [selectedTabIndex, setSelectedTabIndex] = useState(1);

  function onTabSelection(tabIndex: number){
    setSelectedTabIndex(tabIndex);
  }
  
  return (
    <div className="row">
      <div className="col-md-12"> 
        <div className="p-md-2">
          <div className="card">
            <ul className="nav nav-tabs bg-info text-dark">
              <li className="nav-item">
                <a className={selectedTabIndex === 1 ? 'nav-link active' : 'nav-link'} href="#Retail"
                onClick={() => onTabSelection(1)} >Retail</a>
              </li>
              <li className="nav-item">
                <a className={selectedTabIndex === 2 ? 'nav-link active' : 'nav-link'} href="#TravelEnt"
                onClick={() => onTabSelection(2)} >Travel & Entertainment</a>
              </li>
              <li className="nav-item">
                <a className={selectedTabIndex === 3 ? 'nav-link active' : 'nav-link'} href="#Services"
                onClick={() => onTabSelection(3)} >Services</a>
              </li>
            </ul>
            <div className="tab-content ">
                <div className={selectedTabIndex === 1 ? 'tab-pane fade show active' : 'tab-pane fade'} id="home">
                  <Retail />
                </div>
                <div className={selectedTabIndex === 2 ? 'tab-pane fade show active' : 'tab-pane fade'} id="TravelEnt">
                  <TravelEnt />
                </div>
                <div className={selectedTabIndex === 3 ? 'tab-pane fade show active' : 'tab-pane fade'} id="Services">
                  <Services />
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
